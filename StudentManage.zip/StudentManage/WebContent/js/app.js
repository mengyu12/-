/**
 *  获取当前学期
 */

var myDate = new Date();
var year = myDate.getFullYear()
var month = myDate.getMonth();

let term;
if (month < 9) {
	term = year + "年春"
} else {
	term = year + "年秋"
}
document.querySelector('#current-term').innerHTML = "当前学期:&nbsp<b>" + term
		+ "</b>";

$(document).ready(function() {
	$('.dropdown-toggle').dropdown();
});
function shows1(a) {
	$('.buttonText').text(a);
	select();
}
function select() {
	var select;
	console.log(document.getElementById("button").innerText)
	var btntext = document.getElementById("button").innerText;
	console.log(btntext)
	console.log(btntext == "2018年秋")
	console.log(btntext == '2018年秋')
	console.log(btntext.indexOf("2018年秋") != -1)

	if (btntext.indexOf("2019年春") != -1) {
		select = 1
	} else if (btntext.indexOf("2018年秋") != -1) {
		select = 2
	} else if (btntext.indexOf("2018年春") != -1) {
		select = 3
	}
	var ac = document.getElementById("form").action;
	console.log(ac)
	document.getElementById("form").action = ac.substring(0, ac.length - 1)
			+ select;
}

//导出excel
var idTmr; 
function  getExplorer() { 
    var explorer = window.navigator.userAgent ; 
//    ie 
    if (explorer.indexOf("MSIE") >= 0) { 
        return 'ie'; 
    } 
    //firefox 
    else if (explorer.indexOf("Firefox") >= 0) { 
        return 'Firefox'; 
    } 
    //Chrome 
    else if(explorer.indexOf("Chrome") >= 0){ 
        return 'Chrome'; 
    } 
    //Opera 
    else if(explorer.indexOf("Opera") >= 0){ 
        return 'Opera'; 
    } 
    //Safari 
    else if(explorer.indexOf("Safari") >= 0){ 
        return 'Safari'; 
    } 
} 
function exportExcel(tableid,name,filename) { 
    if(getExplorer()=='ie') 
    { 
        var curTbl = document.getElementById(tableid); 
        var oXL = new ActiveXObject("Excel.Application"); 
        var oWB = oXL.Workbooks.Add(); 
        var xlsheet = oWB.Worksheets(1); 
        var sel = document.body.createTextRange(); 
        sel.moveToElementText(curTbl); 
        sel.select(); 
        sel.execCommand("Copy"); 
        xlsheet.Paste(); 
        oXL.Visible = true; 

        try { 
            var fname = oXL.Application.GetSaveAsFilename("Excel.xls", "Excel Spreadsheets (*.xls), *.xls"); 
        } catch (e) { 
            print("Nested catch caught " + e); 
        } finally { 
            oWB.SaveAs(fname); 
            oWB.Close(savechanges = false); 
            oXL.Quit(); 
            oXL = null; 
            idTmr = window.setInterval("Cleanup();", 1); 
        } 

    } 
    else 
    { 
        tableToExcel(tableid,name,filename) 
    } 
} 
function Cleanup() { 
    window.clearInterval(idTmr); 
    CollectGarbage(); 
} 
var tableToExcel = (function() { 
    var uri = 'data:application/vnd.ms-excel;base64,', 
    //Excel样式代码
    template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"'+
                'xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>'
                +'<x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets>'
                +'</x:ExcelWorkbook></xml><![endif]-->'+
                ' <style type="text/css">'+
                '.excelTable  {'+
                'border-collapse:collapse;'+
                 ' border:thin solid #999; '+
                '}'+
                '   .excelTable  th {'+
                '   border: thin solid #999;'+
                '  padding:20px;'+
                '  text-align: center;'+
                '  border-top: thin solid #999;'+
                ' background-color: #E6E6E6;'+
                ' }'+
                ' .excelTable  td{'+
                ' border:thin solid #999;'+
                '  padding:2px 5px;'+
                '  text-align: center;'+
                ' }</style>'+
                '</head><body ><table class="excelTable">{table}</table></body></html>',  
            base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }, 
            format = function(s, c) { 
                return s.replace(/{(\w+)}/g, 
                        function(m, p) { return c[p]; }) } 
    return function(table, name,filename) { 
        if (!table.nodeType) table = document.getElementById(table) 
        var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML} 
        document.getElementById("dlink").href = uri + base64(format(template, ctx));
        document.getElementById("dlink").download = filename;
        document.getElementById("dlink").click();
    } 
})() 
