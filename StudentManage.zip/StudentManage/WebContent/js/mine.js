document.getElementsByName("telephone")[0].onblur=function(){
	if(!(/^1[34578]\d{9}$/.test(this.value))){ 
		alert("电话号码不正确！");
	}
}

function check(){
	var userName=document.getElementsByName("userName")[0].value;
	var gender=document.getElementsByName("gender");
	var selectvalue="";
	for(var i=0;i<gender.length;i++){
		if(gender[i].checked==true){
			selectvalue=gender[i].value;
		}
	}
	var telephone=document.getElementsByName("telephone")[0].value;
	var school=document.getElementsByName("school")[0].value;
	if(userName==""||selectvalue==""||!(/^1[34578]\d{9}$/.test(telephone))||school==""){
		alert("信息未填写完整，请核对!")
		return false;
	}
}
   
    