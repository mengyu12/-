-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: smanage
-- ------------------------------------------------------
-- Server version	5.7.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sm_class`
--

DROP TABLE IF EXISTS `sm_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sm_class` (
  `class_id` varchar(255) NOT NULL,
  `c_id` varchar(255) NOT NULL,
  `class_name` varchar(255) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sm_class`
--

LOCK TABLES `sm_class` WRITE;
/*!40000 ALTER TABLE `sm_class` DISABLE KEYS */;
INSERT INTO `sm_class` VALUES ('1605','2016214000','1605');
/*!40000 ALTER TABLE `sm_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sm_course`
--

DROP TABLE IF EXISTS `sm_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sm_course` (
  `course_id` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `t_id` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sm_course`
--

LOCK TABLES `sm_course` WRITE;
/*!40000 ALTER TABLE `sm_course` DISABLE KEYS */;
INSERT INTO `sm_course` VALUES ('33000000','大学体育','t20062100','2019春','星期五3~4节','体育馆'),('42910017','电动力学','t20062102','2019春','星期三7~8节','3001'),('48720001','C++课程设计','t20062101','2019春','星期一1~2节','6102'),('48921004','Java课程设计','t20062101','2019春','星期二1~2节','7101');
/*!40000 ALTER TABLE `sm_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sm_select_course`
--

DROP TABLE IF EXISTS `sm_select_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sm_select_course` (
  `sele_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `sele_time` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sele_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sm_select_course`
--

LOCK TABLES `sm_select_course` WRITE;
/*!40000 ALTER TABLE `sm_select_course` DISABLE KEYS */;
INSERT INTO `sm_select_course` VALUES (11,'2016214000','48921004','2019春','80'),(12,'2016214001','48921004','2019春','50'),(13,'2016214000','42910017','2019春','0'),(14,'2016210002','33000000','2019春','0');
/*!40000 ALTER TABLE `sm_select_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sm_student`
--

DROP TABLE IF EXISTS `sm_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sm_student` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `birthdaytime` date DEFAULT NULL,
  `sex` int(1) DEFAULT NULL,
  `class_id` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sm_student`
--

LOCK TABLES `sm_student` WRITE;
/*!40000 ALTER TABLE `sm_student` DISABLE KEYS */;
INSERT INTO `sm_student` VALUES ('2016210002','ccc','2016-01-01',1,NULL,NULL,'1206243228@qq.com',''),('2016214000','cy','2016-01-01',1,'1605',NULL,'1206253228@qq.com','13720320489'),('2016214001','my','1998-10-01',0,'1604','2016-09-01','1000000000@qq.com',NULL);
/*!40000 ALTER TABLE `sm_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sm_user`
--

DROP TABLE IF EXISTS `sm_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sm_user` (
  `id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `identity` int(1) NOT NULL,
  `email` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sm_user`
--

LOCK TABLES `sm_user` WRITE;
/*!40000 ALTER TABLE `sm_user` DISABLE KEYS */;
INSERT INTO `sm_user` VALUES ('2016210002','2016210002cy',4,'1206243228@qq.com','ccc'),('2016214000','2016214000',4,'1206253228@qq.com','cy'),('2016214001','2016214001',4,'1111111111@qq.com','小小'),('admin','admin123',1,'2206253228@qq.com','admin'),('c20062000','c20062000',2,'1106253228@qq.com','王二'),('t20062100','t20062100',3,'1216253228@qq.com','张三'),('t20062101','t20062101',3,'1226253228@qq.com','李四'),('t20062102','t20062102',3,'1236111888@163.com','王五');
/*!40000 ALTER TABLE `sm_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'smanage'
--

--
-- Dumping routines for database 'smanage'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-07 11:40:05
