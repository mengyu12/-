package com.coodinator.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.manage.dao.Studentcourse;

 



public class CoodinatorDao {
	private static final String URL = "jdbc:MySQL://localhost:3306/smanage?&useSSL=false&serverTimezone=UTC&characterEncoding=utf-8";
	private static final String USERNAME = "root";
	private static final String PWD = "11112222";
	public List<Studentcourse> queryAll() {//
		List<Studentcourse> stucourses=new ArrayList<>();
		Connection connection=null;
   		PreparedStatement pstmt=null;
   		Studentcourse stucourse=null;
   		ResultSet rs=null;
   		int result=-1;
   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
   		try {
                Class.forName("com.mysql.jdbc.Driver");
                connection=DriverManager.getConnection(URL,USERNAME,PWD);
                String sql="select * from sm_student,sm_select_course,sm_course where sm_select_course.id=sm_student.id && sm_select_course.course_id=sm_course.course_id";
                pstmt=connection.prepareStatement(sql);
                System.out.print("�ɹ��������ݿ�");
                rs=pstmt.executeQuery();
                while(rs.next()) {
               	String sid=rs.getString("id");
               	String name=rs.getString("name"); 
               	String courseid=rs.getString("course_id");
               	String coursename=rs.getString("course_name");
               	String score=rs.getString("score");
               	stucourse=new Studentcourse(sid,name,courseid,coursename,score);
               	stucourses.add(stucourse);
                }
                return stucourses;
   		}catch(ClassNotFoundException e) {
   			e.printStackTrace();
   			return null;//ϵͳ�쳣
   		}catch(SQLException e) {
   			e.printStackTrace();
   			return null;
   		}catch(Exception e) {
   			e.printStackTrace();
   			return null;
   		}finally {
   			try {
   			if(rs!=null) rs.close();
   			if(connection!=null) connection.close();
   			if(pstmt!=null) pstmt.close();
   			}catch(SQLException e) {
   				e.printStackTrace();  			 
   			}catch(Exception e) {
   				e.printStackTrace();
   				 
   			}
   }
    	   
       }
	public List<Studentcourse> querystudentbyyear(String years) {//
		List<Studentcourse> students=new ArrayList<>();
		Connection connection=null;
   		PreparedStatement pstmt=null;
   		Studentcourse student=null;
   		ResultSet rs=null;
   		int result=-1;
   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
   		try {
                Class.forName("com.mysql.jdbc.Driver");
                connection=DriverManager.getConnection(URL,USERNAME,PWD);
                String sql="select * from sm_student,sm_select_course,sm_course where sm_select_course.id=sm_student.id && sm_select_course.course_id=sm_course.course_id && sm_course.year=?";
                System.out.print("��ѯ���ݿ�ɹ�");
                pstmt=connection.prepareStatement(sql);
                pstmt.setString(1,years); 
                rs=pstmt.executeQuery();
                while(rs.next()) {
               	String sid=rs.getString("id");
               	String name=rs.getString("name");
            	String courseid=rs.getString("course_id");
               	String coursename=rs.getString("course_name");
            	String score=rs.getString("score");
               	student=new Studentcourse(sid,name,courseid,coursename,score);
               	students.add(student);
                }
                return students;
   		}catch(ClassNotFoundException e) {
   			e.printStackTrace();
   			return null;//ϵͳ�쳣
   		}catch(SQLException e) {
   			e.printStackTrace();
   			return null;
   		}catch(Exception e) {
   			e.printStackTrace();
   			return null;
   		}finally {
   			try {
   				if(rs!=null) rs.close();
   			if(connection!=null) connection.close();
   			if(pstmt!=null) pstmt.close();
   			}catch(SQLException e) {
   				e.printStackTrace();
   			 
   			}catch(Exception e) {
   				e.printStackTrace();
   				 
   			}
   }
    	   
       }
}
