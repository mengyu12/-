package com.coodinator.servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.coodinator.service.coodinatorservice;

import com.manage.dao.Studentcourse;

public class querystudent extends HttpServlet {
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");	
		 coodinatorservice coodins=new coodinatorservice();
		 HttpSession session=request.getSession();
		 
		 List<Studentcourse> students=coodins.queryall();
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
		 System.out.print("s"); 
		 request.setAttribute("students", students);
		 request.getRequestDispatcher("master/main.jsp").forward(request, response);
	}

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		doGet(request, response);
	}

}
