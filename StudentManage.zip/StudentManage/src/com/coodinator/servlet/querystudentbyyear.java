package com.coodinator.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.coodinator.service.coodinatorservice;

import com.manage.dao.Studentcourse;

 
 
@WebServlet("/querystudentbyyear")
public class querystudentbyyear extends HttpServlet {
	 
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");		
		 String year=request.getParameter("syear");		 
		 coodinatorservice coodins=new coodinatorservice();
		 
		 List<Studentcourse> students=coodins.querybyyear(year);
		 
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
		 System.out.print(year);
		 request.setAttribute("students", students);
		 request.getRequestDispatcher("master/main.jsp").forward(request, response);
		 
	}
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
