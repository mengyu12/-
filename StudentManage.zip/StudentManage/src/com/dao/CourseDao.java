package com.dao;

import java.util.ArrayList;


import com.entity.Course;

public interface CourseDao {
	public ArrayList<Course> listAllCourse() ;//所有课程
	public ArrayList<Course> SearchCourse(String name) throws Exception; //根据课程名称模糊查询
	public ArrayList<Course> listTeacherAllCourse(String tid);//列出老师所有的课程
			
}
