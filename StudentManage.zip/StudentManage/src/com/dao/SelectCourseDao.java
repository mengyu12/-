package com.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.entity.SelectCourse;

public interface SelectCourseDao {
	public int AddSelectCource(SelectCourse sc); //添加选课信息
	public int updateScore(String id,String courseid,String score);  //根据课程编号学生编号更新成绩
	public ArrayList<SelectCourse> QueryScoreByStudentId(String id,String time); //根据学生学号查询成绩
	public ArrayList<SelectCourse> QueryScoreByTeacherId(String cid,String time);  //根据课程编号查询成绩
	public int getSC(SelectCourse sc); //判断是否已选
	public int updateScoreList(String[]courseid,String[]id,String[]score);//修改成绩列表
	
}
