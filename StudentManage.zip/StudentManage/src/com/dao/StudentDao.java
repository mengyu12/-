package com.dao;

import com.entity.Student;
import com.entity.User;

public interface StudentDao {
public String getNameByStudentId(String id); //通过学生编号得到学生姓名
public Student getUserByUserID(String id);//通过学生编号获得学生
public int updateStudent(Student stu);//修改学生信息
public String getClassByStudentId(String id); //通过学生编号得到学生班级
public int addStudent(Student stu);//添加用户


}
