package com.dao;
import java.util.List;

import com.entity.User;
public interface UserDao {
	public int addUser(User user);//添加用户
	public String getUserNameByUserID(String id);//通过用户编号获得用户名
	public User getUserByUserID(String id);//通过用户编号获得用户
	public int getIdentityByUserID(String id); //通过用户编号获取用户身份
	
	
}
