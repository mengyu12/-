package com.dao.impl;

import java.util.ArrayList;

import java.sql.*;
import com.dao.CourseDao;
import com.entity.Course;

import com.utils.JdbcUtils;

public class CourseDaoImpl implements CourseDao {

	@Override
	public ArrayList<Course> listAllCourse() {
		(new JdbcUtils()).getConnection();
		Connection conn=JdbcUtils.con;
		//Boolean boolean1=false;
		if(conn!=null) {
			try {
				ArrayList<Course> al=new ArrayList<>();
				Statement stat=conn.createStatement();
				String sql="select * from sm_course";
				
				ResultSet rs = stat.executeQuery(sql);
				getMoreCourse(al, rs);
				
				conn.close();
				System.out.println("course");
				System.out.println(al.size());
				return al;
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return null;
	}

	

	@Override
	public ArrayList<Course> SearchCourse(String name) throws Exception {
		(new JdbcUtils()).getConnection();
		Connection conn=JdbcUtils.con;
		//Boolean boolean1=false;
		if(conn!=null) {
			try {
				ArrayList<Course> al=new ArrayList<>();
				Statement stat   =conn.createStatement();
				String sql="select * from sm_course where course_name like '%"+name+"%'";
				
				ResultSet rs = stat.executeQuery(sql);
				getMoreCourse(al, rs);
				
				conn.close();
				return al;
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return null;
	}
	@Override
	public ArrayList<Course> listTeacherAllCourse(String tid){
		(new JdbcUtils()).getConnection();
		Connection conn=JdbcUtils.con;
		//Boolean boolean1=false;
		if(conn!=null) {
			try {
				ArrayList<Course> al=new ArrayList<>();
				Statement stat   =conn.createStatement();
				String sql="select * from sm_course where t_id='"+tid+"' and year='2019春'";
				
				ResultSet rs = stat.executeQuery(sql);
				getMoreCourse(al, rs);
				
				conn.close();
				return al;
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return null;
	}

	
	
	private void getMoreCourse(ArrayList<Course> al,ResultSet rs)throws SQLException{
		while(rs.next()) {
			Course course=new Course(rs.getString("course_id"), rs.getString("course_name"), rs.getString("t_id"), rs.getString("year"), rs.getString("time"), rs.getString("place"));
			System.out.println(course.toString());
			al.add(course);
		}
	}
	

}
