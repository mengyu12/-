package com.dao.impl;

import java.util.ArrayList;

import java.sql.*;
import com.dao.SelectCourseDao;

import com.entity.SelectCourse;

import com.utils.JdbcUtils;


public class SelectCourseDaoImpl implements SelectCourseDao{


	@Override
	public int AddSelectCource(SelectCourse sc) {
		String sql="insert into sm_select_course(id,course_id,sele_time,score)values(?,?,?,?)";
		return (int)JdbcUtils.executeSQL(sql,sc.getId(),sc.getCourseid(),sc.getSeletime(),0);
	}

	@Override
	public int updateScore(String id, String courseid, String score) {
		String sql="update sm_select_course set score=? where id=? and course_id=?";
		return (int)JdbcUtils.executeSQL(sql, score,id,courseid);
	}

	@Override
	public ArrayList<SelectCourse> QueryScoreByStudentId(String id,String time){
		(new JdbcUtils()).getConnection();
		Connection conn=JdbcUtils.con;
		if(conn!=null) {
			try {
				ArrayList<SelectCourse> al=new ArrayList<>();
				Statement stat=conn.createStatement();
				
				String sql="select sm_course.course_id,sm_course.course_name,sm_user.name,sm_student.id,sm_student.name,sm_select_course.score,sm_student.class_id,sm_select_course.sele_time from sm_course,sm_select_course,sm_student,sm_user where sm_course.course_id=sm_select_course.course_id and sm_select_course.id=sm_student.id and sm_course.t_id=sm_user.id and sm_user.identity='3' and sm_select_course.sele_time='"+time+"' and sm_select_course.id="+id;
				ResultSet rs = stat.executeQuery(sql);
				getMoreSC(al,rs);
				conn.close();
				System.out.println("stuscore");
				System.out.println(al.size());
				return al;
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
		
	}

	@Override
	public ArrayList<SelectCourse> QueryScoreByTeacherId(String cid,String time) {
		(new JdbcUtils()).getConnection();
		Connection conn=JdbcUtils.con;
		if(conn!=null) {
			try {
			ArrayList<SelectCourse> al=new ArrayList<>();
			Statement stat=conn.createStatement();
			String sql="select sm_course.course_id,sm_course.course_name,sm_student.id,sm_student.name,sm_select_course.score from sm_course,sm_select_course,sm_student  where sm_course.course_id=sm_select_course.course_id  and sm_select_course.id=sm_student.id  and sm_select_course.sele_time='"+time+"' and sm_select_course.course_id='"+cid+"'";
			ResultSet rs = stat.executeQuery(sql);
			getMoreTcs(al,rs);
			conn.close();
			return al;
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return null;
	}
	
	@Override
	public int updateScoreList(String[]courseid,String[]id,String[]score) {
	int len=courseid.length;
	
	System.out.println("len"+len);
	for(int i=0;i<len;i++) {
		this.updateScore(id[i], courseid[i], score[i]);
	}
		
		return 0;
	}
	public void getMoreSC(ArrayList<SelectCourse> al,ResultSet rs)throws SQLException{
		while(rs.next()) {
			System.out.println("coursename"+rs.getString(2));
			System.out.println("name"+rs.getString(5));
			SelectCourse sc=new SelectCourse(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
			al.add(sc);
			System.out.println(sc.toString());
		}
	}
	
    public void getMoreTcs(ArrayList<SelectCourse> al,ResultSet rs)throws SQLException{
    	while(rs.next()) {
    		SelectCourse sc=new SelectCourse(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
    		al.add(sc);
    		System.out.println(sc.toString());
    	}
    }
    
	@Override
	public int getSC(SelectCourse sc) {
		(new JdbcUtils()).getConnection();
		Connection conn=JdbcUtils.con;
		if(conn!=null) {
			try {
		String sql="select * from sm_select_course where id='"+sc.getId()+"' and course_id='"+sc.getCourseid()+"'and sele_time='"+sc.getSeletime()+"'";
		
	    PreparedStatement stat=conn.prepareStatement(sql);
	    ResultSet rs=stat.executeQuery();
	    if(rs.next()) {
	    	return 1;
	    }
	   
	   
	
		
	}catch (Exception e) {
		e.printStackTrace();
	}

}
		return 0;
	}
}
