package com.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

import com.dao.StudentDao;
import com.entity.Student;
import com.utils.JdbcUtils;

public class StudentDaoImpl implements StudentDao {

	@Override
	public String getNameByStudentId(String id) {
		String sql="select name from sm_student where id=?";
		return (String) JdbcUtils.getObjectById(Student.class,sql,id);
	}

	@Override
	public Student getUserByUserID(String id) {
//		String sql="select * from sm_student where id=?";
//		return (Student) JdbcUtils.getObjectById(Student.class, sql, id);
		(new JdbcUtils()).getConnection();
		Connection conn=JdbcUtils.con;
		if(conn!=null) {
			try {
				String sql="select * from sm_student where id=?";
				PreparedStatement stat=conn.prepareStatement(sql);
				stat.setString(1, id);
				 ResultSet rs=stat.executeQuery();
				 if(rs.next()) {
				 Student stu=new Student(rs.getString("id"), rs.getString("name"), rs.getDate("birthdaytime"), rs.getInt("sex"), rs.getString("class_id"), rs.getDate("start_date"), rs.getString("email"), rs.getString("phone"));
				 System.out.println(stu.toString());
				 conn.close();
				 return stu;
				 }else {
					 return null;
				 }
			   }catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return null;
	}
	@Override
	public int addStudent(Student stu) {
		String sql="insert into sm_student(id,name,email)values(?,?,?)";
		return (int)JdbcUtils.executeSQL(sql,stu.getId(),stu.getName(),stu.getEmail());
	}

	@Override
	public int updateStudent(Student stu){
		
		String sql="update sm_student set name=?,sex=?,birthdaytime=?,start_date=?,email=?, phone=? where id=?";
		System.out.println("为什么数据库不对");
		System.out.println(stu.getName()+","+stu.getSex()+","+stu.getBirthdaytime()+","+stu.getStartdate()+","+stu.getEmail()+","+stu.getPhone()+","+stu.getId());
		return (int)JdbcUtils.executeSQL(sql,stu.getName(),stu.getSex(),stu.getBirthdaytime(),stu.getStartdate(),stu.getEmail(),stu.getPhone(),stu.getId());
	}
	
	@Override
	public String getClassByStudentId(String id) {
		String sql="select class_id from sm_student where id=?";
		return (String)JdbcUtils.getObjectById(Student.class, sql, id);
	}
	
	

}
