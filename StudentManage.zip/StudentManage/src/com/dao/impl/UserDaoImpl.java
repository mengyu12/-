package com.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.UserDao;
import com.entity.User;

import com.utils.JdbcUtils;


public class UserDaoImpl implements UserDao{
	private ResultSet resultSet=null;
	
	public int addUser(User user)//添加用户
	{
		String sql="insert into sm_user(name,email,password,id,identity)values(?,?,?,?,?)";
		return (int)JdbcUtils.executeSQL(sql,user.getName(),user.getEmail(),user.getPassword(),user.getId(),user.getIdentity());	
	}
	@Override
	public String getUserNameByUserID(String id) {
		// TODO Auto-generated method stub
		String sql="select name from sm_user where id=?";
		return (String) JdbcUtils.getObjectById(User.class, sql, id);
	}
	@Override
	public User getUserByUserID(String id) {
		// TODO Auto-generated method stub
		String sql="select * from sm_user where id=?";
		return (User) JdbcUtils.getObjectById(User.class, sql, id);
	}
	@Override
	public int getIdentityByUserID(String id){
		// TODO Auto-generated method stub
		String sql="select identity from sm_user where id=?";
		return (int) JdbcUtils.getObjectById(User.class, sql, id);
	}
	
	
}
