package com.entity;


//课程类
public class Course  implements java.io.Serializable{
private String id;
private String name;
private String tid;
private String year;
private String time;
private String place;
public Course() {}
public Course(String id,String name,String tid,String year,String time,String place) {
	this.id=id;
	this.name=name;
	this.tid=tid;
	this.year=year;
	this.time=time;
	this.place=place;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getTid() {
	return tid;
}
public void setTid(String tid) {
	this.tid = tid;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}
@Override
public String toString() {
	return "Course [id="+id+",name="+name+",tid="+tid+",year="+year+",time="+time+",place="+place+"]";
}
}
