package com.entity;

//选课类
public class SelectCourse {
	//  课程号 课程名  教师姓名 学号 姓名 分数  班级  选课时间
	private String id;
	private String courseid;
	private String name;
	private String classid;
	private String coursename;
	private String teacher;
	private String seletime;
	private String score;
	
	public SelectCourse(String id,String courseid,String score) {
		this.id=id;
		this.courseid=courseid;
		this.score=score;
	}
	public SelectCourse(String id,String courseid,String seletime,String score) {
		this.id=id;
		this.courseid=courseid;
		this.seletime=seletime;
		this.score=score;
	}
	public SelectCourse(String courseid,String coursename,String teacher,String id,String name,String score,String classid,String seletime) {
		this.id=id;
		this.courseid=courseid;
		this.coursename=coursename;
		this.name=name;
		this.teacher=teacher;
		this.classid=classid;
		this.seletime=seletime;
		this.score=score;
	}
	public SelectCourse(String courseid,String coursename,String id,String name,String score) {
		this.courseid=courseid;
		this.coursename=coursename;
		this.id=id;
		this.name=name;
		this.score=score;
	}
	
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCourseid() {
		return courseid;
	}
	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}
	public String getSeletime() {
		return seletime;
	}
	public void setSeletime(String seletime) {
		this.seletime = seletime;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	@Override
	public String toString() {
		return "SC [courseid"+courseid+",coursename="+coursename+",teacher="+teacher+",id="+id+",name"+name+",score"+score+",classid="+classid+",seletime="+seletime+"]";
	}
	
}
