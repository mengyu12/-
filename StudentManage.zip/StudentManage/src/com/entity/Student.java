package com.entity;

import java.sql.Date;
//学生类
public class Student  {
private String id;
private String name;
private Date birthdaytime;
private int sex;
private String classid;
private Date startdate;
private String email;
private String phone;

public Student(String id,String name,String email) {
	this.id=id;
	this.name=name;
	this.email=email;
}

public Student(String id,String name,Date birdthdaytime,int sex,String classid,Date startdate,String email,String phone) {
	this.id=id;
	this.name=name;
	this.birthdaytime=birdthdaytime;
	this.sex=sex;
	this.classid=classid;
	this.startdate=startdate;
	this.email=email;
	this.phone=phone;
	
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name=name;
}
public Date getBirthdaytime() {
	return birthdaytime;
}
public void setBirthdaytime(Date birthdaytime) {
	this.birthdaytime = birthdaytime;
}
public int getSex() {
	return sex;
}
public void setSex(int sex) {
	this.sex = sex;
}
public String getClassid() {
	return classid;
}
public void setClassid(String classid) {
	this.classid = classid;
}
public Date getStartdate() {
	return startdate;
}
public void setStartdate(Date startdate) {
	this.startdate = startdate;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email=email;
}

@Override
public String toString() {
	return "[Student [id="+id+",birthdaytime="+birthdaytime+",]";
}
}
