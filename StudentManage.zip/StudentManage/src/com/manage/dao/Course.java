package com.manage.dao;

public class Course {
	private String courseid;
	private String coursename;
	private String tid;
	private String year;
	private String time;
	private String address;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCourseid() {
		return courseid;
	}
	public Course() {
		 
	}
 
	public Course(  String coursename, String tid, String year, String time,String address) {
		 
		 
		this.coursename = coursename;
		this.tid = tid;
		this.year = year;
		this.time = time;
		this.address=address;
	}
	 
	public Course(String courseid, String coursename, String tid, String year, String time,String address) {
		 
		this.courseid = courseid;
		this.coursename = coursename;
		this.tid = tid;
		this.year = year;
		this.time = time;
		this.address=address;
	}
	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

}
