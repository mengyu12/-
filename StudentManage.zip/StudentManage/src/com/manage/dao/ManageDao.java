package com.manage.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

 


public class ManageDao {
		private static final String URL = "jdbc:MySQL://localhost:3306/smanage?&useSSL=false&serverTimezone=UTC&characterEncoding=utf-8";
		private static final String USERNAME = "root";
		private static final String PWD = "11112222";
		public List<Course> querycourseAll() {//��ʾ���еĿγ�
			List<Course> courses=new ArrayList<>();
			Connection connection=null;
	   		PreparedStatement pstmt=null;
	   		Course course=null;
	   		ResultSet rs=null;
	   		int result=-1;
	   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
	   		try {
	                Class.forName("com.mysql.jdbc.Driver");
	                connection=DriverManager.getConnection(URL,USERNAME,PWD);
	                String sql="select * from  sm_course ";
	                pstmt=connection.prepareStatement(sql);
	                rs=pstmt.executeQuery();
	                System.out.print("��ѯ�ɹ�");
	                while(rs.next()) {
	               	String courseid=rs.getString("course_id");
	               	String coursename=rs.getString("course_name"); 
	               	String tid=rs.getString("t_id");
	               	String year=rs.getString("year");
	               	String time=rs.getString("time");
	               	String address=rs.getString("place");
	               	course=new Course(courseid,coursename,tid,year,time,address);
	               	courses.add(course);
	                }
	                return courses;
	   		}catch(ClassNotFoundException e) {
	   			e.printStackTrace();
	   			return null;//ϵͳ�쳣
	   		}catch(SQLException e) {
	   			e.printStackTrace();
	   			return null;
	   		}catch(Exception e) {
	   			e.printStackTrace();
	   			return null;
	   		}finally {
	   			try {
	   				if(rs!=null) rs.close();
	   			if(connection!=null) connection.close();
	   			if(pstmt!=null) pstmt.close();
	   			}catch(SQLException e) {
	   				e.printStackTrace();
	   			 
	   			}catch(Exception e) {
	   				e.printStackTrace();
	   				 
	   			}
	   }
	    	   
	       }
		public List<Course> querycoursebycourid(String courseid) {//ͨ���γ̺Ų�ѯ�γ�
			Connection connection=null;
       		PreparedStatement pstmt=null;
       		List<Course> courses=new ArrayList<>();
       		Course course=null;
       		ResultSet rs=null;
       		int result=-1;
       		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
       		try {
       			Class.forName("com.mysql.jdbc.Driver");
                    connection=DriverManager.getConnection(URL,USERNAME,PWD);
                    String sql="select * from sm_course WHERE course_id=? ";
                    pstmt=connection.prepareStatement(sql);
                    pstmt.setString(1,courseid);
                    System.out.print("��ѯ�ɹ�");
                    rs=pstmt.executeQuery();
                    while(rs.next()) {
                    	String courseid1=rs.getString("course_id");
    	               	String coursename=rs.getString("course_name"); 
    	               	String tid=rs.getString("t_id");
    	               	String year=rs.getString("year");
    	               	String time=rs.getString("time");
    	               	String address=rs.getString("place");
    	               	course=new Course(courseid1,coursename,tid,year,time,address);
    	               	courses.add(course);
                   
                    }
                    return courses;
       		}catch(ClassNotFoundException e) {
       			e.printStackTrace();
       			return null;//ϵͳ�쳣
       		}catch(SQLException e) {
       			e.printStackTrace();
       			return null;
       		}catch(Exception e) {
       			e.printStackTrace();
       			return null;
       		}finally {
       			try {
       				if(rs!=null) rs.close();
       			if(connection!=null) connection.close();
       			if(pstmt!=null) pstmt.close();
       			}catch(SQLException e) {
       				e.printStackTrace();
       			 
       			}catch(Exception e) {
       				e.printStackTrace();
       				 
       			}
       }
        	   
           }
		public Course querycoursebycourid1(String courseid) {//ͨ���γ̺Ų�ѯ�γ�
			Connection connection=null;
       		PreparedStatement pstmt=null;
       	 
       		Course course=null;
       		ResultSet rs=null;
       		int result=-1;
       		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
       		try {
       			Class.forName("com.mysql.jdbc.Driver");
                    connection=DriverManager.getConnection(URL,USERNAME,PWD);
                    String sql="select * from sm_course WHERE course_id=? ";
                    pstmt=connection.prepareStatement(sql);
                    pstmt.setString(1,courseid);
                    System.out.print("��ѯ�ɹ�");
                    rs=pstmt.executeQuery();
                    if(rs.next()) {
                    	String courseid1=rs.getString("course_id");
    	               	String coursename=rs.getString("course_name"); 
    	               	String tid=rs.getString("t_id");
    	               	String year=rs.getString("year");
    	               	String time=rs.getString("time");
    	               	String address=rs.getString("place");
    	               	course=new Course(courseid1,coursename,tid,year,time,address);
    	                
                   
                    }
                    return course;
       		}catch(ClassNotFoundException e) {
       			e.printStackTrace();
       			return null;//ϵͳ�쳣
       		}catch(SQLException e) {
       			e.printStackTrace();
       			return null;
       		}catch(Exception e) {
       			e.printStackTrace();
       			return null;
       		}finally {
       			try {
       				if(rs!=null) rs.close();
       			if(connection!=null) connection.close();
       			if(pstmt!=null) pstmt.close();
       			}catch(SQLException e) {
       				e.printStackTrace();
       			 
       			}catch(Exception e) {
       				e.printStackTrace();
       				 
       			}
       }
        	   
           }
		  public boolean detelebycourseid(String courseid) {//ͨ���γ̺�ɾ���γ�
				Connection connection=null;
		   		PreparedStatement pstmt=null;
		   		int result=-1;
		   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
		   		try {
		   			Class.forName("com.mysql.jdbc.Driver");
		                connection=DriverManager.getConnection(URL,USERNAME,PWD);
		                String sql="delete from sm_course where course_id=?";
		                pstmt=connection.prepareStatement(sql);
		                pstmt.setString(1,courseid);	               
		                int count=pstmt.executeUpdate();
		                if(count>0) {
		                	return true;
		                }
		                else
		                	return false;
		   		}catch(ClassNotFoundException e) {
		   			e.printStackTrace();
		   			return false;//ϵͳ�쳣
		   		}catch(SQLException e) {
		   			e.printStackTrace();
		   			return false;
		   		}catch(Exception e) {
		   			e.printStackTrace();
		   			return false;
		   		}finally {
		   			try {
		   
		   			if(connection!=null) connection.close();
		   			if(pstmt!=null) pstmt.close();
		   			}catch(SQLException e) {
		   				e.printStackTrace();
		   			 
		   			}catch(Exception e) {
		   				e.printStackTrace();
		   				 
		   			}
		   			}
			  
		  }
		  public boolean updateCourseBycourseid(String courseid,Course course) {//����courseid�ҵ��γ̣����޸���
			  Connection connection=null;
		   		PreparedStatement pstmt=null;
		   		int result=-1;
		   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
		   		try {
		                Class.forName("com.mysql.jdbc.Driver");
		                connection=DriverManager.getConnection(URL,USERNAME,PWD);
		                String sql="update sm_course set course_name=?,t_id=?,year=?,time=?,place=? where course_id=?";
		                pstmt=connection.prepareStatement(sql);
		                pstmt.setString(1,course.getCoursename());
		                pstmt.setString(2, course.getTid());	
		                pstmt.setString(3,course.getYear());	
		                pstmt.setString(4,course.getTime());
		                pstmt.setString(5,course.getAddress());
		                pstmt.setString(6,courseid);	
		                int count=pstmt.executeUpdate();
		                if(count>0) {
		                	return true;
		                }
		                else
		                	return false;
		   		}catch(ClassNotFoundException e) {
		   			e.printStackTrace();
		   			return false;//ϵͳ�쳣
		   		}catch(SQLException e) {
		   			e.printStackTrace();
		   			return false;
		   		}catch(Exception e) {
		   			e.printStackTrace();
		   			return false;
		   		}finally {
		   			try {
		   
		   			if(connection!=null) connection.close();
		   			if(pstmt!=null) pstmt.close();
		   			}catch(SQLException e) {
		   				e.printStackTrace();
		   			 
		   			}catch(Exception e) {
		   				e.printStackTrace();
		   				 
		   			}
		   			}
			  
		  }
			public boolean addCourse( Course course) {
				Connection connection=null;
		   		PreparedStatement pstmt=null;
		   		int result=-1;
		   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
		   		try {
		                Class.forName("com.mysql.jdbc.Driver");
		                connection=DriverManager.getConnection(URL,USERNAME,PWD);
		                String sql="insert into sm_course values(?,?,?,?,?,?) ";
		                pstmt=connection.prepareStatement(sql);
		                pstmt.setString(1,course.getCourseid());
		                pstmt.setString(2,course.getCoursename());
		                pstmt.setString(3,course.getTid());
		                pstmt.setString(4,course.getYear());
		                pstmt.setString(5,course.getTime());
		                pstmt.setString(6,course.getAddress());
		                int count=pstmt.executeUpdate();
		                if(count>0) {
		                	return true;
		                }
		                else
		                	return false;
		   		}catch(ClassNotFoundException e) {
		   			e.printStackTrace();
		   			return false;//ϵͳ�쳣
		   		}catch(SQLException e) {
		   			e.printStackTrace();
		   			return false;
		   		}catch(Exception e) {
		   			e.printStackTrace();
		   			return false;
		   		}finally {
		   			try {
		   
		   			if(connection!=null) connection.close();
		   			if(pstmt!=null) pstmt.close();
		   			}catch(SQLException e) {
		   				e.printStackTrace();
		   			 
		   			}catch(Exception e) {
		   				e.printStackTrace();
		   				 
		   			}
		   }
		    	   
		       }
		  public List<Studentcourse> querystudentAll(String courseid) {//����һ���γ��ҵ�ѡ���ſε�ѧ��
				List<Studentcourse> stucourses=new ArrayList<>();
				Connection connection=null;
		   		PreparedStatement pstmt=null;
		   		Studentcourse stucourse=null;
		   		ResultSet rs=null;
		   		int result=-1;
		   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
		   		try {
		   			Class.forName("com.mysql.jdbc.Driver");
		                connection=DriverManager.getConnection(URL,USERNAME,PWD);
		                String sql="select * from sm_select_course,sm_student where course_id=?";
		                pstmt=connection.prepareStatement(sql);
		                pstmt.setString(1,courseid);
		                rs=pstmt.executeQuery();
		                while(rs.next()) {
		               	String sid=rs.getString("id");
		               	String name=rs.getString("name"); 
		               	System.out.print("��ѯ�ɹ�");
		               	stucourse=new Studentcourse(sid,name);
		               	stucourses.add(stucourse);
		                }
		                return stucourses;
		   		}catch(ClassNotFoundException e) {
		   			e.printStackTrace();
		   			return null;//ϵͳ�쳣
		   		}catch(SQLException e) {
		   			e.printStackTrace();
		   			return null;
		   		}catch(Exception e) {
		   			e.printStackTrace();
		   			return null;
		   		}finally {
		   			try {
		   				if(rs!=null) rs.close();
		   			if(connection!=null) connection.close();
		   			if(pstmt!=null) pstmt.close();
		   			}catch(SQLException e) {
		   				e.printStackTrace();
		   			 
		   			}catch(Exception e) {
		   				e.printStackTrace();
		   				 
		   			}
		   }
		    	   
		       }
		  public boolean detelestubyid(String id) {//ͨ��id��ɾ��һЩѡ�ε�ѧ��
				Connection connection=null;
		   		PreparedStatement pstmt=null;
		   		int result=-1;
		   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
		   		try {
		   			Class.forName("com.mysql.jdbc.Driver");
		                connection=DriverManager.getConnection(URL,USERNAME,PWD);
		                String sql="delete from sm_select_course where id=?";
		                pstmt=connection.prepareStatement(sql);
		                pstmt.setString(1,id);	               
		                int count=pstmt.executeUpdate();
		                if(count>0) {
		                	return true;
		                }
		                else
		                	return false;
		   		}catch(ClassNotFoundException e) {
		   			e.printStackTrace();
		   			return false;//ϵͳ�쳣
		   		}catch(SQLException e) {
		   			e.printStackTrace();
		   			return false;
		   		}catch(Exception e) {
		   			e.printStackTrace();
		   			return false;
		   		}finally {
		   			try {
		   
		   			if(connection!=null) connection.close();
		   			if(pstmt!=null) pstmt.close();
		   			}catch(SQLException e) {
		   				e.printStackTrace();
		   			 
		   			}catch(Exception e) {
		   				e.printStackTrace();
		   				 
		   			}
		   			}
			  
		  }
		  public List<sclass> queryclassAll() {//��ʾ���еİ༶
				List<sclass> sclasses=new ArrayList<>();
				Connection connection=null;
		   		PreparedStatement pstmt=null;
		   		sclass sclass1=null;
		   		ResultSet rs=null;
		   		int result=-1;
		   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
		   		try {
		                Class.forName("com.mysql.jdbc.Driver");
		                connection=DriverManager.getConnection(URL,USERNAME,PWD);
		                String sql="select * from  sm_class ";
		                pstmt=connection.prepareStatement(sql);
		                rs=pstmt.executeQuery();
		                while(rs.next()) {
		               	String classid=rs.getString("class_id");
		               	String cid=rs.getString("c_id");
		               	String classname=rs.getString("class_name");
		               	sclass1=new sclass(classid,classname, cid);
		               	sclasses.add(sclass1);
		                }
		                return sclasses;
		   		}catch(ClassNotFoundException e) {
		   			e.printStackTrace();
		   			return null;//ϵͳ�쳣
		   		}catch(SQLException e) {
		   			e.printStackTrace();
		   			return null;
		   		}catch(Exception e) {
		   			e.printStackTrace();
		   			return null;
		   		}finally {
		   			try {
		   				if(rs!=null) rs.close();
		   			if(connection!=null) connection.close();
		   			if(pstmt!=null) pstmt.close();
		   			}catch(SQLException e) {
		   				e.printStackTrace();
		   			 
		   			}catch(Exception e) {
		   				e.printStackTrace();
		   				 
		   			}
		   }
		    	   
		       }
			public sclass queryclassbycourid(String classid) {//ͨ���༶�Ų�ѯ�༶
				Connection connection=null;
	       		PreparedStatement pstmt=null;
	       		sclass sclass1=null;
	       		ResultSet rs=null;
	       		int result=-1;
	       		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
	       		try {
	       			Class.forName("com.mysql.jdbc.Driver");
	                    connection=DriverManager.getConnection(URL,USERNAME,PWD);
	                    String sql="select * from sm_class WHERE class_id=? ";
	                    pstmt=connection.prepareStatement(sql);
	                    pstmt.setString(1,classid);
	                   
	                    rs=pstmt.executeQuery();
	                    if(rs.next()) {
	                    	String classid1=rs.getString("class_id");
			               	String cid=rs.getString("c_id");
			               	String classname=rs.getString("class_name");
			               	sclass1=new sclass(classid,classname, cid);
	    	  
	                   
	                    }
	                    return sclass1;
	       		}catch(ClassNotFoundException e) {
	       			e.printStackTrace();
	       			return null;//ϵͳ�쳣
	       		}catch(SQLException e) {
	       			e.printStackTrace();
	       			return null;
	       		}catch(Exception e) {
	       			e.printStackTrace();
	       			return null;
	       		}finally {
	       			try {
	       				if(rs!=null) rs.close();
	       			if(connection!=null) connection.close();
	       			if(pstmt!=null) pstmt.close();
	       			}catch(SQLException e) {
	       				e.printStackTrace();
	       			 
	       			}catch(Exception e) {
	       				e.printStackTrace();
	       				 
	       			}
	       }
	        	   
	           }
			public List<sclass> queryclassbycourid1(String classid) {//ͨ���༶�Ų�ѯ�༶
				List<sclass> sclasses=new ArrayList<>();
				Connection connection=null;
	       		PreparedStatement pstmt=null;
	       		sclass sclass1=null;
	       		ResultSet rs=null;
	       		int result=-1;
	       		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
	       		try {
	       			Class.forName("com.mysql.jdbc.Driver");
	                    connection=DriverManager.getConnection(URL,USERNAME,PWD);
	                    String sql="select * from sm_class WHERE class_id=? ";
	                    pstmt=connection.prepareStatement(sql);
	                    pstmt.setString(1,classid);
	                   
	                    rs=pstmt.executeQuery();
	                    while(rs.next()) {
	                    	String classid1=rs.getString("class_id");
			               	String cid=rs.getString("c_id");
			               	String classname=rs.getString("class_name");
			               	sclass1=new sclass(classid,classname, cid);
			               	sclasses.add(sclass1);
	                   
	                    }
	                    return sclasses;
	       		}catch(ClassNotFoundException e) {
	       			e.printStackTrace();
	       			return null;//ϵͳ�쳣
	       		}catch(SQLException e) {
	       			e.printStackTrace();
	       			return null;
	       		}catch(Exception e) {
	       			e.printStackTrace();
	       			return null;
	       		}finally {
	       			try {
	       				if(rs!=null) rs.close();
	       			if(connection!=null) connection.close();
	       			if(pstmt!=null) pstmt.close();
	       			}catch(SQLException e) {
	       				e.printStackTrace();
	       			 
	       			}catch(Exception e) {
	       				e.printStackTrace();
	       				 
	       			}
	       }
	        	   
	           }
			  public boolean detelebyclassid(String classid) {//ͨ�����ɾ���γ�
					Connection connection=null;
			   		PreparedStatement pstmt=null;
			   		int result=-1;
			   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
			   		try {
			   			Class.forName("com.mysql.jdbc.Driver");
			                connection=DriverManager.getConnection(URL,USERNAME,PWD);
			                String sql="delete from sm_class where class_id=?";
			                pstmt=connection.prepareStatement(sql);
			                pstmt.setString(1,classid);	               
			                int count=pstmt.executeUpdate();
			                if(count>0) {
			                	return true;
			                }
			                else
			                	return false;
			   		}catch(ClassNotFoundException e) {
			   			e.printStackTrace();
			   			return false;//ϵͳ�쳣
			   		}catch(SQLException e) {
			   			e.printStackTrace();
			   			return false;
			   		}catch(Exception e) {
			   			e.printStackTrace();
			   			return false;
			   		}finally {
			   			try {
			   
			   			if(connection!=null) connection.close();
			   			if(pstmt!=null) pstmt.close();
			   			}catch(SQLException e) {
			   				e.printStackTrace();
			   			 
			   			}catch(Exception e) {
			   				e.printStackTrace();
			   				 
			   			}
			   			}
				  
			  }
			  public List<Studentcourse> querystudentbyclassid(String classid) {//����һ���γ��ҵ�ѡ���ſε�ѧ��
					List<Studentcourse> stucourses=new ArrayList<>();
					Connection connection=null;
			   		PreparedStatement pstmt=null;
			   		Studentcourse stucourse=null;
			   		ResultSet rs=null;
			   		int result=-1;
			   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
			   		try {
			   			Class.forName("com.mysql.jdbc.Driver");
			                connection=DriverManager.getConnection(URL,USERNAME,PWD);
			                String sql="select * from sm_student where class_id=?";
			                pstmt=connection.prepareStatement(sql);
			                pstmt.setString(1,classid);
			                rs=pstmt.executeQuery();
			                while(rs.next()) {
			               	String sid=rs.getString("id");
			               	String name=rs.getString("name"); 
			                
			                
			               	stucourse=new Studentcourse(sid,name);
			               	stucourses.add(stucourse);
			                }
			                return stucourses;
			   		}catch(ClassNotFoundException e) {
			   			e.printStackTrace();
			   			return null;//ϵͳ�쳣
			   		}catch(SQLException e) {
			   			e.printStackTrace();
			   			return null;
			   		}catch(Exception e) {
			   			e.printStackTrace();
			   			return null;
			   		}finally {
			   			try {
			   				if(rs!=null) rs.close();
			   			if(connection!=null) connection.close();
			   			if(pstmt!=null) pstmt.close();
			   			}catch(SQLException e) {
			   				e.printStackTrace();
			   			 
			   			}catch(Exception e) {
			   				e.printStackTrace();
			   				 
			   			}
			   }
			    	   
			       }
			  public boolean detelestubyclassid(String id) {//ͨ��id��ɾ��һЩѡ�ε�ѧ��
					Connection connection=null;
			   		PreparedStatement pstmt=null;
			   		int result=-1;
			   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
			   		try {
			   			Class.forName("com.mysql.jdbc.Driver");
			                connection=DriverManager.getConnection(URL,USERNAME,PWD);
			                String sql="delete from sm_class where id=?";
			                pstmt=connection.prepareStatement(sql);
			                pstmt.setString(1,id);	               
			                int count=pstmt.executeUpdate();
			                if(count>0) {
			                	return true;
			                }
			                else
			                	return false;
			   		}catch(ClassNotFoundException e) {
			   			e.printStackTrace();
			   			return false;//ϵͳ�쳣
			   		}catch(SQLException e) {
			   			e.printStackTrace();
			   			return false;
			   		}catch(Exception e) {
			   			e.printStackTrace();
			   			return false;
			   		}finally {
			   			try {
			   
			   			if(connection!=null) connection.close();
			   			if(pstmt!=null) pstmt.close();
			   			}catch(SQLException e) {
			   				e.printStackTrace();
			   			 
			   			}catch(Exception e) {
			   				e.printStackTrace();
			   				 
			   			}
			   			}
				  
			  }
			  public boolean updateClassByclassid(String classid,sclass sclass1) {//����classid�ҵ��༶�����޸���
				  Connection connection=null;
			   		PreparedStatement pstmt=null;
			   		int result=-1;
			   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
			   		try {
			                Class.forName("com.mysql.jdbc.Driver");
			                connection=DriverManager.getConnection(URL,USERNAME,PWD);
			                String sql="update sm_class set c_id=?,class_name=? where class_id=?";
			                pstmt=connection.prepareStatement(sql);
			                pstmt.setString(1,sclass1.getCid());
			                pstmt.setString(2,sclass1.getClasssname());	
			                pstmt.setString(3,classid);			                	
			                int count=pstmt.executeUpdate();
			                if(count>0) {
			                	return true;
			                }
			                else
			                	return false;
			   		}catch(ClassNotFoundException e) {
			   			e.printStackTrace();
			   			return false;//ϵͳ�쳣
			   		}catch(SQLException e) {
			   			e.printStackTrace();
			   			return false;
			   		}catch(Exception e) {
			   			e.printStackTrace();
			   			return false;
			   		}finally {
			   			try {
			   
			   			if(connection!=null) connection.close();
			   			if(pstmt!=null) pstmt.close();
			   			}catch(SQLException e) {
			   				e.printStackTrace();
			   			 
			   			}catch(Exception e) {
			   				e.printStackTrace();
			   				 
			   			}
			   			}
				  
			  }
			  public boolean addClass( sclass sclass1) {
					Connection connection=null;
			   		PreparedStatement pstmt=null;
			   		int result=-1;
			   		int flag=-1;//-1ϵͳ�쳣   1�ɹ�   0��������
			   		try {
			                Class.forName("com.mysql.jdbc.Driver");
			                connection=DriverManager.getConnection(URL,USERNAME,PWD);
			                String sql="insert into sm_class values(?,?,?) ";
			                pstmt=connection.prepareStatement(sql);
			                pstmt.setString(1,sclass1.getClassid());
			                pstmt.setString(2,sclass1.getCid());
			                pstmt.setString(3,sclass1.getClasssname());
			              
			                int count=pstmt.executeUpdate();
			                if(count>0) {
			                	return true;
			                }
			                else
			                	return false;
			   		}catch(ClassNotFoundException e) {
			   			e.printStackTrace();
			   			return false;//ϵͳ�쳣
			   		}catch(SQLException e) {
			   			e.printStackTrace();
			   			return false;
			   		}catch(Exception e) {
			   			e.printStackTrace();
			   			return false;
			   		}finally {
			   			try {
			   
			   			if(connection!=null) connection.close();
			   			if(pstmt!=null) pstmt.close();
			   			}catch(SQLException e) {
			   				e.printStackTrace();
			   			 
			   			}catch(Exception e) {
			   				e.printStackTrace();
			   				 
			   			}
			   }
			    	   
			       }
	}
