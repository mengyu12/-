package com.manage.dao;

public class sclass {
	private String classid;
	private String cid;
	private String classsname;
	private String id;
	public sclass() {
		 
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public sclass(String classid, String classsname,String cid ) {
		this.classid = classid;
		this.cid = cid;
		this.classsname = classsname;
	}
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getClasssname() {
		return classsname;
	}
	public void setClasssname(String classsname) {
		this.classsname = classsname;
	}
	

}
