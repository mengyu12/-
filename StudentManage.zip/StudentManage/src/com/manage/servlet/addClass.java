package com.manage.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.manage.service.manageservice;

import com.manage.dao.Course;
import com.manage.dao.sclass;

/**
 * Servlet implementation class addClass
 */
@WebServlet("/addClass")
public class addClass extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");		
		 String id=request.getParameter("sid");
		 String name=request.getParameter("sname");
		 String cid=request.getParameter("scid");
		 System.out.print("����");
		 sclass sclass1=new sclass(id,name,cid);
		 manageservice manageser=new manageservice();
		 boolean result=manageser.addClass(sclass1);
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
		 if(result) {			 
			 response.sendRedirect("queryclassall");
		 }
		 else {
			 out.print("�޸�ʧ��");
		 }
	}
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
