package com.manage.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.manage.service.manageservice;

/**
 * Servlet implementation class detelestubyid
 */
@WebServlet("/detelestubyid")
public class detelestubyid extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");		
		 String sid=request.getParameter("sid");
		 manageservice manageser=new  manageservice();
		 boolean result=manageser.detelestubyid(sid);
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
		 if(result) {
			
			//out.print("ɾ���ɹ�");
			 response.sendRedirect("querystudentall");
		 }
		 else {
			 out.print("ɾ��ʧ��");
		 }
	}
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
		doGet(request, response);
	}

}
