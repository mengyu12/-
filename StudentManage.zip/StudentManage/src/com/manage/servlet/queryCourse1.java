package com.manage.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.manage.service.manageservice;

import com.manage.dao.Course;

/**
 * Servlet implementation class queryCourse1
 */
@WebServlet("/queryCourse1")
public class queryCourse1 extends HttpServlet {
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");		
		 String courseid=request.getParameter("scourseid");
	 
		 
		 manageservice mservice=new manageservice();
		 Course course=mservice.querycoursebycourid1(courseid);
		 // out ����PrintWriter out= response.getWriter()
		 //session response.getSession();
		 //application:request.getServletContext()
		 //������Ӧ����
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
		// System.out.print();
		 request.setAttribute("course",  course);
		 request.getRequestDispatcher("admin/courseinfo.jsp").forward(request, response);
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
