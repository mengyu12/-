package com.manage.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.manage.dao.ManageDao;
import com.manage.dao.sclass;

/**
 * Servlet implementation class queryclassbyid1
 */
@WebServlet("/queryclassbyid1")
public class queryclassbyid1 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");		
		 String classid=request.getParameter("sclassid");
	 
		 
		 ManageDao managedao=new ManageDao();
		 List<sclass>  sclasses=managedao.queryclassbycourid1(classid);
		 // out ����PrintWriter out= response.getWriter()
		 //session response.getSession();
		 //application:request.getServletContext()
		 //������Ӧ����
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
	 
		 request.setAttribute("sclasses", sclasses);
		 request.getRequestDispatcher("admin/class.jsp").forward(request, response);
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
