package com.manage.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.manage.service.manageservice;

import com.manage.dao.Course;
import com.manage.dao.ManageDao;

/**
 * Servlet implementation class querybyid
 */
@WebServlet("/querycoursebycourid")
public class querycoursebycourid extends HttpServlet {
	 

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");		
		 String courseid=request.getParameter("scourseid");
	 
		 
		 manageservice mservice=new manageservice();
		 List<Course> courses=mservice.querycoursebycourid(courseid);
		 // out ����PrintWriter out= response.getWriter()
		 //session response.getSession();
		 //application:request.getServletContext()
		 //������Ӧ����
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
		// System.out.print();
		 request.setAttribute("courses", courses);
		 request.getRequestDispatcher("admin/main.jsp").forward(request, response);
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
