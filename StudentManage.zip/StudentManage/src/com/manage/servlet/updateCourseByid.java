package com.manage.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.manage.service.manageservice;

import com.manage.dao.Course;

/**
 * Servlet implementation class updateCourseByid
 */
@WebServlet("/updateCourseByid")
public class updateCourseByid extends HttpServlet {
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("utf-8");		
		 String id=request.getParameter("sid");
		 String name=request.getParameter("sname");
		 String tid=request.getParameter("stid");
		 String year=request.getParameter("syear");
		 String time=request.getParameter("stime");
		 String address=request.getParameter("saddress");
		 Course course=new Course(name,tid,year,time,address);
		 manageservice manageser=new manageservice();
		 boolean result=manageser.updateCourseBycourseid(id, course);
		 response.setContentType("text/html;charset=utf-8");
		 response.setCharacterEncoding("utf-8");
		 PrintWriter out= response.getWriter();
		 if(result) {
			
			 
			 response.sendRedirect("querycourseall");
		 }
		 else {
			 out.print("�޸�ʧ��");
		 }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
