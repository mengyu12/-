package com.service.Impl;

import com.dao.StudentDao;
import com.dao.impl.StudentDaoImpl;
import com.entity.Student;
import com.service.StudentService;

public class StudentServiceImpl implements StudentService{
	 private StudentDao  studentDao;
	 public StudentServiceImpl() {
		// TODO Auto-generated constructor stub
		 studentDao=new StudentDaoImpl();
	}
	@Override
	public String getNameByStudentId(String id) {
		// TODO Auto-generated method stub
		
		return studentDao.getNameByStudentId(id);
	}

	@Override
	public Student getUserByUserID(String id) {
		// TODO Auto-generated method stub
		return studentDao.getUserByUserID(id);
	}

	@Override
	public int updateStudent(Student stu) {
		// TODO Auto-generated method stub
		return studentDao.updateStudent(stu);
	}

	@Override
	public String getClassByStudentId(String id) {
		// TODO Auto-generated method stub
		return studentDao.getClassByStudentId(id);
	}

	@Override
	public int addStudent(Student stu) {
		// TODO Auto-generated method stub
		if(getUserByUserID(stu.getId())!=null) {
			return 2;
		}
		return studentDao.addStudent(stu);
	}

}
