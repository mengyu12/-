package com.service.Impl;

import com.entity.User;
import com.service.UserService;

import com.utils.JdbcUtils;

import java.sql.Connection;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;

public class UserServiceImpl implements UserService{
	 private UserDao userDao;
     public UserServiceImpl() {
    	 userDao = new UserDaoImpl();
     }
	@Override
	public int getUserNameByUserID(String id){
		// TODO Auto-generated method stub
		if(getUserByUserID(id)==null) {
			return 1;
		}
		else
			return 2;
		//return userDao.getUserIDByEmail(email);
	}

	@Override
	public User getUserByUserID(String id) {
		// TODO Auto-generated method stub
		return userDao.getUserByUserID(id);
	}
	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		if(getUserByUserID(user.getId())!=null) {
			return 2;
		}
		return userDao.addUser(user);
	}
	@Override
	public User login(String id, String password) {
		// TODO Auto-generated method stub
		Connection connection = null;
		User user = null;
		try {
			connection = JdbcUtils.getConnection();
			user = userDao.getUserByUserID(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JdbcUtils.close(null,null,connection);
		}
		
		if(user != null){
			if(!user.getPassword().equals(password)){
				user=null;
				System.out.println("密码错误！");
			}else {
				System.out.println("登陆成功");
			}
		}
		return user;

	}
	@Override
	public int getIdentityByUserID(String id) {
		// TODO Auto-generated method stub		
		return userDao.getIdentityByUserID(id);
	}
	
	

	

}
