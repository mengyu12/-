package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.StudentDao;
import com.dao.impl.StudentDaoImpl;
import com.entity.Student;
import com.entity.User;
import com.service.UserService;
import com.service.Impl.UserServiceImpl;



public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public loginServlet() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;utf-8");
		response.setCharacterEncoding("utf-8");
		
		response.setContentType("text/html;charset=UTF-8");
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		//登录错误保持填写的表单
		request.setAttribute("id", id);
		request.setAttribute("password", password);
		
		UserService userservice = new UserServiceImpl();
		User user=userservice.login(id, password);
		PrintWriter out=response.getWriter();
		//String userName=userservice.getUserNameByEmail(email);
		if(null!=user) {
			System.out.println(user.getName());
			//获取session
			HttpSession session=request.getSession();
			session.setAttribute("id", id);
			session.setAttribute("user",user);
			
			session.setAttribute("userName",user.getName());
			session.setAttribute("identity", user.getIdentity());
			if(user.getIdentity()==4) {
				//得到学生详细信息
				StudentDao studao=new StudentDaoImpl();
				Student student=studao.getUserByUserID(id);
				session.setAttribute("student", student);
				//计算年龄
				String age="";
				if(student.getBirthdaytime()!=null) {
					Calendar cal=Calendar.getInstance();
					int yearnow=cal.get(Calendar.YEAR);
					cal.setTime(student.getBirthdaytime());
					int birthyear=cal.get(Calendar.YEAR);
					 age=yearnow-birthyear+"";	
				}
				session.setAttribute("age", age);
				session.setAttribute("classid", student.getClassid());
				
			}
			String src="";
			switch (user.getIdentity()) {
			case 1:
				src="querycourseall";
				break;
			case 2:
				src="querystudent";
				break;
			case 3:
				src="teachercourseServlet";
				break;
			case 4:
			{	
				src="allcourseServlet";
				break;
			}
			default:
				break;
			}
			System.out.println(src);
			//客户端跳转response
			response.sendRedirect(src);
			//request.getRequestDispatcher(src).forward(request, response);
			}
			else {
				
				int m=userservice.getUserNameByUserID(id);
				if(m==1) {
				out.println("<script>alert(\"用户未注册!\");window.location.href='login.jsp';</script>");
		}else {
				out.println("<script>alert(\"密码不正确\");window.location.href='login.jsp';</script>");
				}
				
			}
		}
	}
	
	
	

