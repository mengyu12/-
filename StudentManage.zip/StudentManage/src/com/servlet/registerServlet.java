package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.Student;
import com.entity.User;
import com.service.StudentService;
import com.service.UserService;
import com.service.Impl.StudentServiceImpl;
import com.service.Impl.UserServiceImpl;
import com.sun.corba.se.spi.ior.Identifiable;

public class registerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public registerServlet() {
		super();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;utf-8");
		response.setCharacterEncoding("utf-8");
		String userName = request.getParameter("userName");
		String userId=request.getParameter("userId");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		int identity=Integer.parseInt(request.getParameter("identity"));
		System.out.println("1"+userName);
		System.out.println(userId);
		System.out.println(email);
		System.out.println(password);
		System.out.println(identity);
		System.out.println("开始注册");
		    UserService userservice = new UserServiceImpl();
		    //String userName,String email,String password,String id,int identity)
		    //name,email,password,id,identity
		    User user = new User(userName,email,password,userId,identity);
		    PrintWriter out=response.getWriter();
		    //添加学生注册
		    if(identity==4) {
		    	StudentService studentService=new StudentServiceImpl();
		    	Student student=new Student(userId, userName, email);
		    	int n=studentService.addStudent(student);
		    }
		    int m = userservice.addUser(user);
		    if(m!=2) {
			System.out.println("注册成功");
			HttpSession session = request.getSession();
			session.setAttribute("userId", userId);
			session.setAttribute("userName",userName);
			session.setAttribute("email", email);
			out.println("<script>alert(\"注册成功!跳转登录页\");setTimeout('window.location.href=\"login.jsp\";',1000);</script>");
		    }else if(m==2) {
		    	 out.println("<script>alert(\"用户已经注册！请登录\");window.location.href='register.jsp';</script>");
		    }
		   else {
			   out.println("<script>alert(\"注册失败\");window.location.href='register.jsp';</script>");
		  }
	}
		
	
		
		
		
}


