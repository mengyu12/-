package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.CourseDao;
import com.dao.impl.CourseDaoImpl;
import com.entity.Course;
@WebServlet("/searchcourseServlet")
public class searchcourseServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	        this.doPost(request, response);
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	        response.setContentType("text/html;charset=utf-8");
	        response.setCharacterEncoding("utf-8");
	        request.setCharacterEncoding("utf-8");

	        PrintWriter out = response.getWriter();
	        HttpSession session = request.getSession();
	        CourseDao course=new CourseDaoImpl();
	        String name = request.getParameter("classname");
	        System.out.println("searchname"+name);
	        ArrayList<Course> courses=null;
			try {
				courses = course.SearchCourse(name);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        session.setAttribute("CourseList", courses);
	        request.getRequestDispatcher("student/main.jsp").forward(request, response);
	       
	        
	    
	    }
}
