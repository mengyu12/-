package com.servlet;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.SelectCourseDao;
import com.dao.impl.SelectCourseDaoImpl;

import com.entity.SelectCourse;


@WebServlet("/selectScoreServlet")
public class selectScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html;charset=utf-8");
	        response.setCharacterEncoding("utf-8");
	        request.setCharacterEncoding("utf-8");
	        
	       HttpSession session = request.getSession();
	        String id=(String)request.getSession().getAttribute("id");
	        String select=request.getParameter("s");
	        System.out.println(select);
	        String time="";
	        System.out.println(select.equals("1"));
	        if(select.equals("1")) {
	        	time="2019春";
	        }else if(select.equals("2")) {
	        	time="2018秋";
	        }else if(select.equals("3")) {
	        	time="2018春";
	        }
	        System.out.println("time"+time);
	        
	        System.out.println("id"+id);
	      
	   SelectCourseDao scDao=new SelectCourseDaoImpl();
	    ArrayList<SelectCourse> SCList=null;
	    try {
	    	SCList=scDao.QueryScoreByStudentId(id, time);
	    }catch (Exception e) {
			// TODO: handle exception
	    	e.printStackTrace();
		}
	   
	    System.out.println(SCList.size());
	   session.setAttribute("SCList", SCList);
	  //response.sendRedirect("student/score.jsp");
	   
	    request.getRequestDispatcher("student/score.jsp").forward(request, response);
	}
}
