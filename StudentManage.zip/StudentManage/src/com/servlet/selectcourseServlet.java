package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import com.dao.SelectCourseDao;
import com.dao.impl.CourseDaoImpl;
import com.dao.impl.SelectCourseDaoImpl;
import com.entity.Course;
import com.entity.SelectCourse;


//选课
@WebServlet("/selectcourseServlet")
public class selectcourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;utf-8");
		response.setCharacterEncoding("utf-8");
		
		String cid=request.getParameter("cid");
		String id=(String)request.getSession().getAttribute("id");
		 PrintWriter out=response.getWriter();
		System.out.println("SC   cid,id"+cid+id);
		//选课时间
		Calendar now=Calendar.getInstance();
		int year=now.get(Calendar.YEAR);
		int month=now.get(Calendar.MONTH);
		String seletime=year+"";
		if(month<9) {
			seletime+="春";
		}else {
			seletime+="秋";
		}
		SelectCourseDao selectCourseDao=new SelectCourseDaoImpl();
		SelectCourse sc=new SelectCourse(id, cid, seletime, "");
		int m=selectCourseDao.getSC(sc);
		System.out.print("m"+m);
		if(m==1) {
			
			out.println("<script>alert(\"该课程已选上,不可重复选课\");window.location.href='student/main.jsp';</script>");
		}else {
		int n=selectCourseDao.AddSelectCource(sc);
		out.println("<script>alert(\"选课成功\");window.location.href='student/main.jsp';</script>");
		//out.println("<script>alert(\"选课成功\");window.location.href='student/main.jsp';</script>");
		//request.getRequestDispatcher("student/main.jsp").forward(request, response);
		}
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		
	}


}
