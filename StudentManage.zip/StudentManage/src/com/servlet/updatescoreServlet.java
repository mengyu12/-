package com.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.SelectCourseDao;
import com.dao.StudentDao;
import com.dao.impl.SelectCourseDaoImpl;
import com.dao.impl.StudentDaoImpl;
import com.entity.SelectCourse;

@WebServlet("/updatescoreServlet")
public class updatescoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

 	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;utf-8");
		response.setCharacterEncoding("utf-8");
		//request.getParameter("TCscoreList");
		//ArrayList<SelectCourse> aSelectCourses=request.getParameterMap("TCscoreList<id>");
		String[] courseid=request.getParameterValues("courseid");
		System.out.println(courseid[0]);
		String[] id=request.getParameterValues("id");
		String[] score=request.getParameterValues("score");
		SelectCourseDao scDao=new SelectCourseDaoImpl();
		scDao.updateScoreList(courseid, id, score);
		
		response.sendRedirect("teacher/main.jsp");
	}	

}
