package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.dao.StudentDao;
import com.dao.impl.StudentDaoImpl;
import com.entity.Student;

@WebServlet("/updatestudentServlet")
public class updatestudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

 	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;utf-8");
		response.setCharacterEncoding("utf-8");
		String id=(String)request.getSession().getAttribute("id");
		String name = request.getParameter("name");
		String sex0=request.getParameter("sex");
		String birthdaytime0=request.getParameter("birthdaytime");
		String startdate0=request.getParameter("startdate");
		String email=request.getParameter("email");
		String phone = request.getParameter("phone");
		String classid=(String)request.getSession().getAttribute("classid");
		
		int sex=sex0=="男"?0:1;
		//转java.sql.Date对象
		SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		Date birdthdaytime=null;
		
		Date startdate=null;
		try {
			birdthdaytime=new java.sql.Date(dateFormat.parse(birthdaytime0).getTime());
			startdate=new java.sql.Date(dateFormat.parse(startdate0).getTime());
			System.out.println("1-");
			System.out.print(startdate);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
	
		
		System.out.println(name);
		System.out.println(sex);
		System.out.println(email);
		System.out.println(phone);
		System.out.print(startdate);
		System.out.println(birdthdaytime);	
		System.out.println("修改");
		
		
		   StudentDao studentDao=new StudentDaoImpl();
		    PrintWriter out=response.getWriter();
		   Student student=new Student(id, name, birdthdaytime, sex, classid, startdate, email, phone);
		   
		   studentDao.updateStudent(student);
		   
			HttpSession session = request.getSession();
			session.setAttribute("student", student);
			session.setAttribute("name",name);
			
		//	out.println("<script>alert(\"个人信息修改成功\");</script>");
			 //request.getRequestDispatcher("student/userset.jsp").forward(request, response);
			  response.sendRedirect("student/userset.jsp");  
			// out.println("<script>alert(\"个人信息修改成功\");window.location.href='student/userset.jsp';</script>");
			
			
	}
}
