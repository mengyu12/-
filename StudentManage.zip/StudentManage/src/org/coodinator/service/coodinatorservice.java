package org.coodinator.service;

import java.util.List;

 

import com.coodinator.dao.CoodinatorDao;
import com.manage.dao.Studentcourse;

public class coodinatorservice {
	CoodinatorDao coodinatordao=new CoodinatorDao();
	public List<Studentcourse> queryall() {
		return coodinatordao.queryAll();
	}
	public List<Studentcourse> querybyyear(String year){
		return coodinatordao.querystudentbyyear(year);
	}
}
