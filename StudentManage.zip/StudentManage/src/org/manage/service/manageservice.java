package org.manage.service;

import java.util.List;

import com.manage.dao.Course;
import com.manage.dao.ManageDao;
import com.manage.dao.Studentcourse;
import com.manage.dao.sclass;

public class manageservice {
          ManageDao managedao=new ManageDao();
          public List<Course> querycourseall() {
        	 return  managedao.querycourseAll();
          }
          public List<Course> querycoursebycourid(String courseid){
        	  return managedao.querycoursebycourid(courseid);
          }
          public Course querycoursebycourid1(String courseid){
        	  return managedao.querycoursebycourid1(courseid);
          }
          public boolean detelebycourseid(String courseid) {
        	return   managedao.detelebycourseid(courseid);
          }
          public boolean updateCourseBycourseid(String courseid,Course course) {
        	  return   managedao.updateCourseBycourseid(courseid, course);
          }
      	public boolean addCourse( Course course) {
      		 return   managedao.addCourse(course);
      	}
      	public List<Studentcourse> querystudentAll(String courseid) {
      		return managedao.querystudentAll(courseid);
      	}
          public boolean  detelestubyid(String id) {
        	  return managedao. detelestubyid(id);
          }
          public List<Studentcourse> querystudentbyclassid(String classid) {
        	  return managedao.querystudentbyclassid(classid);
          }
          public List<sclass> queryclassAll() {
        	  return managedao.queryclassAll();
          }
          public sclass queryclassbycourid(String classid) {
        	  return managedao.queryclassbycourid(classid);
          }
          public boolean detelebyclassid(String classid) {
        	  return managedao.detelebyclassid(classid);
          }
          public boolean detelestubyclassid(String id) {
        	  return managedao.detelestubyclassid(id);
          }
          public List<sclass> queryclassbycourid1(String classid) {
        	  return managedao.queryclassbycourid1(classid);
          }
          public boolean updateClassByclassid(String classid,sclass sclass1) {
        	  return managedao.updateClassByclassid(classid, sclass1);
          }
          public boolean addClass( sclass sclass1) {
        	  return managedao.addClass(sclass1);
          }
}
